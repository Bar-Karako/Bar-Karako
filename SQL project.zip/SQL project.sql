USE [master]
GO

if exists (select * from sysdatabases where name='ifexists')
	drop database IFEXISTS
GO

/****** Object:  Database [IFEXISTS]    Script Date: 7/18/2019 1:31:45 PM ******/
CREATE DATABASE [IFEXISTS]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'IFEXISTS', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\IFEXISTS.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'IFEXISTS_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\IFEXISTS_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
GO

ALTER DATABASE [IFEXISTS] SET COMPATIBILITY_LEVEL = 140
GO

IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [IFEXISTS].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO

ALTER DATABASE [IFEXISTS] SET ANSI_NULL_DEFAULT OFF 
GO

ALTER DATABASE [IFEXISTS] SET ANSI_NULLS OFF 
GO

ALTER DATABASE [IFEXISTS] SET ANSI_PADDING OFF 
GO

ALTER DATABASE [IFEXISTS] SET ANSI_WARNINGS OFF 
GO

ALTER DATABASE [IFEXISTS] SET ARITHABORT OFF 
GO

ALTER DATABASE [IFEXISTS] SET AUTO_CLOSE OFF 
GO

ALTER DATABASE [IFEXISTS] SET AUTO_SHRINK OFF 
GO

ALTER DATABASE [IFEXISTS] SET AUTO_UPDATE_STATISTICS ON 
GO

ALTER DATABASE [IFEXISTS] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO

ALTER DATABASE [IFEXISTS] SET CURSOR_DEFAULT  GLOBAL 
GO

ALTER DATABASE [IFEXISTS] SET CONCAT_NULL_YIELDS_NULL OFF 
GO

ALTER DATABASE [IFEXISTS] SET NUMERIC_ROUNDABORT OFF 
GO

ALTER DATABASE [IFEXISTS] SET QUOTED_IDENTIFIER OFF 
GO

ALTER DATABASE [IFEXISTS] SET RECURSIVE_TRIGGERS OFF 
GO

ALTER DATABASE [IFEXISTS] SET  DISABLE_BROKER 
GO

ALTER DATABASE [IFEXISTS] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO

ALTER DATABASE [IFEXISTS] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO

ALTER DATABASE [IFEXISTS] SET TRUSTWORTHY OFF 
GO

ALTER DATABASE [IFEXISTS] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO

ALTER DATABASE [IFEXISTS] SET PARAMETERIZATION SIMPLE 
GO

ALTER DATABASE [IFEXISTS] SET READ_COMMITTED_SNAPSHOT OFF 
GO

ALTER DATABASE [IFEXISTS] SET HONOR_BROKER_PRIORITY OFF 
GO

ALTER DATABASE [IFEXISTS] SET RECOVERY FULL 
GO

ALTER DATABASE [IFEXISTS] SET  MULTI_USER 
GO

ALTER DATABASE [IFEXISTS] SET PAGE_VERIFY CHECKSUM  
GO

ALTER DATABASE [IFEXISTS] SET DB_CHAINING OFF 
GO

ALTER DATABASE [IFEXISTS] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO

ALTER DATABASE [IFEXISTS] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO

ALTER DATABASE [IFEXISTS] SET DELAYED_DURABILITY = DISABLED 
GO

ALTER DATABASE [IFEXISTS] SET QUERY_STORE = OFF
GO

USE [IFEXISTS]
GO

ALTER DATABASE SCOPED CONFIGURATION SET IDENTITY_CACHE = ON;
GO

ALTER DATABASE SCOPED CONFIGURATION SET LEGACY_CARDINALITY_ESTIMATION = OFF;
GO

ALTER DATABASE SCOPED CONFIGURATION FOR SECONDARY SET LEGACY_CARDINALITY_ESTIMATION = PRIMARY;
GO

ALTER DATABASE SCOPED CONFIGURATION SET MAXDOP = 0;
GO

ALTER DATABASE SCOPED CONFIGURATION FOR SECONDARY SET MAXDOP = PRIMARY;
GO

ALTER DATABASE SCOPED CONFIGURATION SET PARAMETER_SNIFFING = ON;
GO

ALTER DATABASE SCOPED CONFIGURATION FOR SECONDARY SET PARAMETER_SNIFFING = PRIMARY;
GO

ALTER DATABASE SCOPED CONFIGURATION SET QUERY_OPTIMIZER_HOTFIXES = OFF;
GO

ALTER DATABASE SCOPED CONFIGURATION FOR SECONDARY SET QUERY_OPTIMIZER_HOTFIXES = PRIMARY;
GO

ALTER DATABASE [IFEXISTS] SET  READ_WRITE 
GO


GO

use IFEXISTS

	----------COMPANIES-------------
	GO
	CREATE TABLE dbo.Companies
	(
	CompanyID INT PRIMARY KEY not null,
	CompanyName NVARCHAR(20) NOT NULL,
	CompanyState NVARCHAR (20) NOT NULL,
	CompanyCity NVARCHAR (20) NOT NULL,
	CompanyStreet NVARCHAR (20) NOT NULL,
	CompanyNumOfStreet NVARCHAR (20) NOT NULL,
	CompanyAddressComment NVARCHAR (20),
	MinOptions int, 
	MaxPreferred int,

	constraint Min_options check(MinOptions>=0),
	constraint Max_Preferred check (MaxPreferred>0)
	)
	GO

	---ROLES----
	Create table dbo.Roles (
	CompanyID int  REFERENCES Companies(companyID) NOT NULL,
	RoleID int primary key  not null,
	RoleDescription char(20) not null
	)
	GO
	----ShiftTypes-----
		create table ShiftTypes(
	shifttype int primary key,
	shiftname nvarchar(20)  not null
	)
	GO
	
-------------SHIFT STRUCTURE----------
	CREATE TABLE dbo.ShiftStructure(
	
	ShiftType int references ShiftTypes(ShiftType) not null,
	RoleID int REFERENCES Roles (RoleID),
	amount int NOT NULL,
	constraint SHIFT_STRUCTURE_KEY primary key (ShiftType,RoleID)
	)
	GO
---------------Employees ---------------
	create table dbo.Employees (

	companyID int  REFERENCES companies(companyID) NOT NULL,
	EmployeeNumber int IDENTITY(1,1),
	EmployeeID nvarchar(9) not null,
	EmployeeRole int REFERENCES Roles(RoleID),
	FirstName nvarchar(20) not null,
	LastName nvarchar(20) not null,
	City nvarchar(20) not null,
	Street nvarchar(20) not null,
	HouseNumber int not null,
	PhoneNumber nvarchar(20) null,
	hourpay float Not Null,
	BirthDate DATE Not Null,
	Email nvarchar(40) Not Null,
	
	constraint EmpCompKey primary key (CompanyID,EmployeeID),
	constraint CKEmail check (Email like '%@%.%'),     
	constraint CKFirstName check (FirstName NOT LIKE '%[^A-Z]%')
	)
	GO
		--------SHIFTS-----
	create table dbo.shifts(
	companyID int REFERENCES companies(CompanyID)  not null,
	shiftID int primary key,
	ShiftDate date not null,
	ShiftStartTime time  not null, 
	ShiftEndTime time  not null,
	SalaryCoefficient float not null,
	IsClosed  int  not null,
	ShiftType  int references ShiftTypes(ShiftType) not null,

	constraint CKDate check (shiftDate <= getdate()),
	constraint CKSALRYCOEF check (salarycoefficient >= 1)
	)
	GO

	-------SHIFT DETAILS-----
	CREATE TABLE dbo.ShiftsDetails	(
	
	ShiftID  int REFERENCES Shifts(shiftid) NOT NULL,
	CompanyID  int REFERENCES Companies(companyID) NOT NULL,
	EmployeeID nvarchar(9)  NOT NULL,
	ShiftDate date NOT NULL,
	EmpStartTime time NOT NULL,
	EmpEndTime time NOT NULL,
	Salaryperhour float NOT NULL,

	constraint Key_for_shift primary key (shiftID,EmployeeID),
	CONSTRAINT CKshiftDATE CHECK(ShiftDate <= GETDATE())
	)
	go
	
	--------Login_details-------------
	create table dbo.LoginDetails	(
	CompanyId int REFERENCES companies(companyID) not null, 
	PremissionType int not null,
	EmployeeID nvarchar(9)  not null, 
	username nvarchar(20) not null unique, 
	password nvarchar(20),
	
	constraint Key_for_Login primary key (CompanyID,EmployeeID)
	)
	go

	--------SHift_OPTIONS----------
	CREATE TABLE dbo.Shiftsoptions  (
	companyID int  REFERENCES companies(companyID) NOT NULL,
	shiftID INT  REFERENCES shifts(shiftID) NOT NULL,
	EmployeeID nvarchar(9)  NOT NULL,
	Preferation INT not null,


    CONSTRAINT PKShiftsOptions PRIMARY KEY (shiftID,EmployeeID),
    )

	go


		--------DAY_STRUCTURE ----------

	CREATE TABLE dbo.DAY_STRUCTURE (
	companyID int REFERENCES companies(CompanyID)  not null,
	ShiftType  int references ShiftTypes(ShiftType) not null,
	ShiftStartTime time not null, 
	ShiftEndTime time not null,
	
	CONSTRAINT PKDayStracture PRIMARY KEY (CompanyID,ShiftType),
		)

	go









GO



/*STARTING TO INSERT DATA INTO TABLES*/


use IFEXISTS;
BEGIN TRANSACTION 

INSERT INTO Companies--(CompanyID,CompanyName,companyCity,CompanyStreet,CompanyNumOfStreet,CompanyState)
VALUES(1376225,'Cafe Cafe','Ramat Gan','Ben Gurion',1,'Gush Dan','None',0,5)
,(1425210,'Bank Leumi', 'Tel-Aviv','Ibn Gvirol',35,'Gush Dan','None',0,6)

INSERT INTO Roles 
VALUES(1376225,1,'Cook'),(1376225,2,'Waiter'),(1376225,3,'Shift Supervisor'),(1376225,4,'DB Manager'),(1376225,5,'Cleaner'),
(1425210,6,'Phone Banker'),(1425210,7,'Teller'),(1425210,8,'Shift Supervisor'),(1425210,9,'DB Manager')

GO

insert into ShiftTypes
values(1,'Morning'),(2,'Afternoon'),(3,'Day'),(4,'Evening')
GO

INSERT INTO ShiftStructure
VALUES(1,1,2) --2 Cooks
,(1,2,3) --3 Waiters
,(1,3,1) -- 1 Shift Supervisor
,(1,4,1)  --1 DB Manager
,(1,5,1)  --1 Cleaner
,(2,1,1) --1 Cook
,(2,2,2) --2 Waiters
,(2,3,1) -- 1 Shift Supervisor
,(2,4,1)  --1 DB Manager
,(2,5,1)  --1 Cleaner
,(3,1,7) --7 Phone Bankers
,(3,2,3) -- 3 Tellers
,(3,3,1)  --1 Shift Supervisor
,(3,4,1)  --1 DB Manager

,(4,6,5) --5 Phone Bankers
,(4,7,2) -- 2 Tellers
,(4,8,1)  --1 Shift Supervisor
,(4,9,1)  --1 DB Manager


/*INSERT INTO shifts
VALUES(1,1376225,'2019-07-18'*/



INSERT INTO Employees  (CompanyID,EmployeeID,EmployeeRole,FirstName,LastName,City,Street,HouseNumber,PhoneNumber,hourpay,BirthDate,Email)
VALUES(1376225,'063051706',1,'Yair','Menusi','Petach Tikva','Pinchas',190,'053-6450809',50,DATEFROMPARTS ( 1985, 12, 31 ),'YairM@gmail.com'),
	  (1376225,'054990834',1,'Moshe','Cohen','Savion','Hertzel',15,'052-8871532',50,DATEFROMPARTS ( 1982, 2, 14 ),'Moshe_Cohen@walla.com'),
	  (1376225,'030209872',2,'Moshe','Amiri','Yehud','Weizman',115,'050-1431592',30,DATEFROMPARTS ( 1992, 10, 11 ),'MosheA13@hotmail.com'),
	  (1376225,'020294572',2,'Gary','Moskovich','Ramat Hachaial','Raul Valenberg',115,'052-9452734',30,DATEFROMPARTS ( 1991, 5, 6 ),'MoskovichG@gmail.com'),
	  (1376225,'020207574',2,'Moshe','Kapron','Yehud','Haarad',125,'050-8821010',30,DATEFROMPARTS ( 1995, 10, 16 ),'Moshe24@gmail.com'),
	  (1376225,'060072311',2,'Amir','Levi','Ramat Hasharon','Weizman',89,'050-4436092',30,DATEFROMPARTS ( 1992, 4, 21 ),'AmirLevi@hotmail.com'),
	  (1376225,'069079324',2,'Avi','Narkis','Beit Shemesh','Hazon Ish',95,'054-4379152',30,DATEFROMPARTS ( 1993, 10, 20 ),'AviNarkis@hotmail.com'),
	  (1376225,'060209872',3,'Tsachi','Betla','Petach Tikva','Hatavor',10,'050-2031696',37,DATEFROMPARTS ( 1988, 6, 11 ),'TsachBet@gmail.com'),
	  (1376225,'030909935',4,'David','Katzir','Herzelyia','Sokolov',115,'050-6101594',65,DATEFROMPARTS ( 1986, 3, 21 ),'KatzirDavid@hotmail.com'),
	  (1376225,'062855492',5,'Yosi','Shaulov','Natanya','Shlomo Goren',14,'054-7491028',30,DATEFROMPARTS ( 1999, 10, 1 ),'Yosi20@hotmail.com'),
	  (1425210,'038624236',6,'Moshe','Shapira','Tel-Aviv','Weizman',80,'054-2775791',30,DATEFROMPARTS ( 1995, 7, 11 ),'MosheShapira@gmail.com'),
	  (1425210,'020209175',6,'Evyatar','Cahana','Givataim','Hamaagal',2,'052-3125068',30,DATEFROMPARTS ( 1994, 8, 23 ),'evya20@gmail.com'),
	  (1425210,'035020879',6,'Einav','Ophira','Tel-Aviv','Weizman',15,'053-2526101',30,DATEFROMPARTS ( 1996, 3, 12 ),'Einavush11@gmail.com'),
	  (1425210,'065521237',6,'Yaron','Mualem','Ramat Gan','Byalik',12,'050-1296731',30,DATEFROMPARTS ( 1992, 1, 27 ),'Yaron__22@gmail.com'),
	  (1425210,'032002843',6,'Miki','Dekel','Petach Tikva','Shtempeper',12,'052-8196429',30,DATEFROMPARTS ( 1987, 7, 22 ),'Miki_Dekel@gmail.com'),
	  (1425210,'065630926',6,'Zohar','Avisa','Tel Aviv','Hayarkon',12,'050-4103960',30,DATEFROMPARTS ( 1989, 2, 15 ),'Zohar20@gmail.com'),
	  (1425210,'063889115',6,'Rotem','Bar-On','Ramat Gan','Hertzel',55,'052-5461686',30,DATEFROMPARTS ( 1991, 5, 17 ),'RotemBO12@gmail.com'),
	  (1425210,'060462913',6,'Daniel','Akirov','Tel Aviv','Nordao',12,'052-2093972',30,DATEFROMPARTS ( 1989, 3, 20 ),'DanielAk209@gmail.com'),
	  (1425210,'063292505',7,'Keren','Tavas','Tel Aviv','Gordon',80,'052-8143923',30,DATEFROMPARTS ( 1996, 4, 14 ),'Keren23@gmail.com'),
	  (1425210,'027676238',7,'Ami','Adelshtein','Petach Tikva','Gordon',12,'052-8143923',30,DATEFROMPARTS ( 1996, 4, 14 ),'Ami@gmail.com'),
	  (1425210,'049025071',7,'Beni','Kovolo','Yafo','Gordon',44,'052-8143923',30,DATEFROMPARTS ( 1990, 9, 24 ),'BeniXXX@gmail.com'),
	  (1425210,'063051907',7,'Mark','Cohen','Givataim','Hamalben',39,'050-7373327',30,DATEFROMPARTS ( 1997, 11, 28 ),'Marko@gmail.com'),
	  (1425210,'045639135',8,'Gadi','Dahari','Tel Aviv','Arlozerov',19,'050-8803924',38,DATEFROMPARTS ( 1991, 9, 20 ),'Gadiii@gmail.com'),
	  (1425210,'062009119',9,'tsvika','Samol','Tel Aviv','Dizengof',19,'052-7826726',60,DATEFROMPARTS ( 1992, 1, 5 ),'Tsvikas@gmail.com')
	 
	 
	  INSERT INTO Shifts(companyID,shiftID,ShiftDate,ShiftStartTime,ShiftEndTime,SalaryCoefficient,IsClosed,ShiftType)
	  VALUES(1376225,12,DATEFROMPARTS ( 2019, 7, 18 ),'08:00','16:00',1,1,1),
	  (1376225,13,DATEFROMPARTS ( 2019, 7, 18 ),'15:00','22:00',1.25,1,2),
	  (1425210,14,DATEFROMPARTS ( 2019, 7, 17 ),'08:00','17:00',1,1,3),
	  (1425210,15,DATEFROMPARTS ( 2019, 7, 17 ),'16:00','23:00',1.25,1,4),
	  (1425210,17,DATEFROMPARTS ( 2019, 7, 17 ),'16:00','23:00',1.25,0,4)

	  
	  
	  INSERT INTO ShiftsDetails
	  VALUES(12,1376225,'063051706',DATEFROMPARTS ( 2019, 7, 18 ),'08:00','16:15',50),
	  (12,1376225,'060072311',DATEFROMPARTS ( 2019, 7, 18 ),'08:00','16:00',30),
	  (12,1376225,'069079324',DATEFROMPARTS ( 2019, 7, 18 ),'08:00','16:00',30),
	  (12,1376225,'030209872',DATEFROMPARTS ( 2019, 7, 18 ),'08:02','16:00',30),
	  (12,1376225,'020294572',DATEFROMPARTS ( 2019, 7, 18 ),'08:02','16:00',30),

	  (13,1376225,'054990834',DATEFROMPARTS ( 2019, 7, 18 ),'15:50','22:00',50),
	  (13,1376225,'020207574',DATEFROMPARTS ( 2019, 7, 18 ),'16:00','22:00',30),

	  (14,1425210,'065630926',DATEFROMPARTS ( 2019, 7, 17 ),'08:00','15:55',30),
	  (14,1425210,'063889115',DATEFROMPARTS ( 2019, 7, 17 ),'08:00','16:00',30),

	  (15,1425210,'060462913',DATEFROMPARTS ( 2019, 7, 17 ),'16:00','23:00',30),
	  (15,1425210,'032002843',DATEFROMPARTS ( 2019, 7, 17 ),'16:00','23:00',30),
	  ------
	 
	  (17,1376225,'054990834',DATEFROMPARTS ( 2019, 7, 18 ),'15:50','22:00',50),
	  (17,1376225,'020207574',DATEFROMPARTS ( 2019, 7, 18 ),'16:00','22:00',30),

	  (17,1425210,'065630926',DATEFROMPARTS ( 2019, 7, 17 ),'08:00','15:55',30),
	  (17,1425210,'063889115',DATEFROMPARTS ( 2019, 7, 17 ),'08:00','16:00',30),

	  (17,1425210,'060462913',DATEFROMPARTS ( 2019, 7, 17 ),'16:00','23:00',30),
	  (17,1425210,'032002843',DATEFROMPARTS ( 2019, 7, 17 ),'16:00','23:00',30)




	  INSERT INTO LoginDetails
	VALUES(1376225,1,'063051706','Yair','ym2060'),
	(1376225,4,'030909935','DavidK','480yyo'),
	(1425210,1,'065630926','ZoharAvi','zo3011100'),
	(1425210,4,'062009119','Tsvik','ts40000')

	INSERT INTO DAY_STRUCTURE
	VALUES(1376225,1,'08:00','16:00'),
	(1376225,2,'16:00','22:00'),
	(1425210,3,'08:00','17:00'),
	(1425210,4,'17:00','23:00')

	 INSERT INTO Shiftsoptions
	 VALUES(1376225,12,'063051706',12),
	 (1376225,12,'060072311',12),
	 (1376225,12,'069079324',12),
	 (1376225,12,'030209872',12),
	 (1376225,12,'020294572',13),
	 (1376225,13,'054990834',13),
	 (1376225,13,'020207574',13),
	 (1425210,14,'065630926',14),
	 (1425210,14,'063889115',14),
	 (1425210,15,'060462913',14),
	 (1425210,15,'032002843',15),
	 -----
	  (1376225,17,'054990834',13),
	 (1376225,17,'020207574',13),
	 (1425210,17,'065630926',14),
	 (1425210,17,'063889115',14),
	 (1425210,17,'060462913',14),
	 (1425210,17,'032002843',15)
 

 





-------=======================------- shift arangements by dates  -----=============================------

go

create procedure  dbo.WeekShifts 
@compID as int,
@date1 as date,
@date2 as date
as
select sd.CompanyID, sd.ShiftID, sd.ShiftDate, sd.EmpStartTime, sd.EmpEndTime, sd.EmployeeID
from ShiftsDetails sd
where sd.CompanyID = @compID
and sd.ShiftDate >= @date1 and sd.ShiftDate<=@date2
go



/*exec dbo.WeekShifts @compID =1376225, @date1 = '2019-07-01', @date2 = '2019-08-01';*/

---====================================================================================================---


--================================-VIEW employees details---------==================================-----------

go

CREATE VIEW ed_employee_details
AS
SELECT E.EmployeeID, E.FirstName, E.LastName, LD.username, LD.password, C.CompanyID, C.CompanyName, E.EmployeeRole
FROM Employees E left JOIN Companies C ON E.CompanyID = C.CompanyID 
					JOIN LoginDetails LD ON E.EmployeeID = LD.EmployeeId AND E.companyID = LD.CompanyID

go

------------------==============================-procedure employees details by employee id ans company id===========================

create proc employee_details (@emp_id int, @company_id int)
as
SELECT *
FROM ed_employee_details ED
WHERE ED.EmployeeID = @emp_id and ED.CompanyID = @company_id

go

--===============================================exampe fot execute procedure==================================-------------------------
/*
exec employee_details @emp_id = 063051706, @company_id = 1376225
*/


---================================COMPANY SETTINGS====================================================================-------------
GO
-----------
CREATE PROCEDURE dbo.CompanySettings(@CompanyID INT, @StartDate DATE, @EndDate DATE) AS
SELECT C.CompanyID, C.CompanyName ,C.MaxPreferred, C.MinOptions, DS.ShiftType,  DS.ShiftStartTime, DS.ShiftEndTime, count(S.ShiftID) as ShiftsInWeek
FROM DAY_STRUCTURE AS DS 
			LEFT JOIN Shifts AS S ON DS.ShiftType = S.ShiftType
			LEFT JOIN Companies AS C ON C.CompanyID = DS.companyID
WHERE S.ShiftDate BETWEEN @StartDate AND @EndDate
GROUP BY C.CompanyID, C.CompanyName ,C.MaxPreferred, C.MinOptions, DS.ShiftType, DS.ShiftStartTime, DS.ShiftEndTime
HAVING C.CompanyID = @CompanyID 
GO
/*
EXEC dbo.CompanySettings @CompanyID =1376225, @StartDate='2019-07-14', @EndDate='2019-07-20'
*/
--------==============================================================================================-----------------


---===================================--shift is open/close-----========================----------	 
go
CREATE function dbo.Isopen(@shiftID int)
RETURNS NVARCHAR(MAX)
as 
BEGIN
DECLARE @isclosed INT = (select isclosed from shifts
							 WHERE @shiftID=shiftID)

DECLARE	@closed NVARCHAR(MAX) = 'THE SHIFT IS CLOSED FOR CHANGES',
		@open NVARCHAR(MAX)	='THE SHIFT IS OPEN FOR CHANGES'	
		if @isclosed = 1
		RETURN @closed
		RETURN @open 
END
		

go


-----------====================================================----------------------------------------
--------=================shift changes - PROCEDURE TO CHANGE SHIFTS==================------------------
CREATE PROCEDURE [dbo].[Changes]
@empID nvarchar(10),@shiftID INT,@change INT
as
begin
	DECLARE @isclosed INT = (select isclosed from shifts
							 WHERE @shiftID=shiftID)

	DECLARE @current INT = (select preferation from shiftsoptions
				    where EmployeeID=@empID AND shiftID=@shiftID)

	if(@isclosed=1)
			PRINT 'THE SHIFT IS CLOSED FOR CHANGES'		
		ELSE IF(@current=@change)
				PRINT 'Your request is your current preferation'
	ELSE IF( @change IN (12,13,14,15) AND @isclosed<>1 AND @current<>@change )
		UPDATE [dbo].[Shiftsoptions]
		SET Preferation=@change
		where EmployeeID=@empID AND shiftID=@shiftID
	ELSE 
	PRINT 'The change should be between 12 and 15'
end

/*
exec [dbo].[Changes]  '020207574',12,15
*/
-------==========================================================================----------------


--=======================func salaryPerEmployee=====================----------------
go
create view vw_sum_hours
as

select sd.CompanyID,sd.EmployeeID,sd.Salaryperhour,sd.ShiftDate,sd.ShiftID, hourPerShift=
		(CASE WHEN DATEDIFF(MI,sd.EmpEndTime,sd.EmpStartTime) <0 THEN abs((DATEDIFF(MI,sd.EmpStartTime,sd.EmpEndTime))/60.0)
		else (DATEDIFF(MI,sd.EmpStartTime,sd.EmpEndTime))/60.0
		END )
from ShiftsDetails sd
go

create function salaryPerEmployee(@compID int, @id nvarchar(10),@start_date date,@end_date date) returns float
begin
	declare @salary float
	set @salary=(select sum(vw.hourPerShift*sd.Salaryperhour*s.salarycoefficient)
				 from ShiftsDetails sd inner join vw_sum_hours vw on sd.EmployeeID=vw.EmployeeID inner join shifts s on vw.ShiftID=s.shiftID
				 where @compID =vw.CompanyID  and  sd.EmployeeID=@id and sd.ShiftDate between @start_date and @end_date)
	return @salary
end

go
/*
select * from Companies
select * from ShiftsDetails where EmployeeID like '020294572'
*/



-------salary per worker between dates--------
/*
select isnull(dbo.salaryPerEmployee (1376225, '020294572','2019-01-01','2019-08-09'),0) as Salary
*/


--------=======================----------------=============----------------------
----------===============================================-----------------+
GO
create function dbo.Total_Salary (@companyID INT, @startdate date,@enddate date)
RETURNS FLOAT
begin
DECLARE @TotalSalary FLOAT
SET @TotalSalary= (SELECT SUM(dbo.salaryPerEmployee(@companyID, employeeID, @startdate,@enddate)) as TotalSalary FROM employees)
RETURN @TotalSalary
END
GO
GO
CREATE function dbo.Total_employees_Salaries (@company INT, @start date,@end date)
RETURNS TABLE
AS
RETURN		select d.companyID, d.TotalSalaryGross, SUM(d.hourPerShift) as SUMofHours,d.TotalSalaryGross*0.3 as MasHachnasa, d.TotalSalaryGross*0.7 as TotalSalaryNet  
			from (SELECT vw.companyID, vw.hourPerShift, dbo.Total_Salary(@company, @start, @end) as TotalSalaryGross
			FROM vw_sum_hours as VW  WHERE vw.CompanyID=@company AND vw.ShiftDate BETWEEN @start AND @end) as d
			GROUP BY d.companyID,d.TotalSalaryGross,d.TotalSalaryGross*0.3, d.TotalSalaryGross*0.7
GO

/*
select * from Companies
select * from Total_employees_Salaries (1376225,'2019-01-01','2019-12-12')
select * from Employees where companyID = 1376225

select sum(dbo.salaryPerEmployee(1376225, e.EmployeeID ,'2019-01-01','2019-12-12'))
from Employees e
*/
GO


CREATE VIEW vw_Shifts_by 
as
select so.[companyID], so.[shiftID],so.EmployeeID,so.Preferation, s.[ShiftDate],s.ShiftStartTime,s.ShiftEndTime,s.ShiftType
from Shiftsoptions so left join shifts s 
on so.shiftID= s.shiftID
GO


/*select * from ShiftsDetails order by EmployeeID*/


GO
CREATE function dbo.shifts_1 (@companyid int,@employeeid  nvarchar(10), @startdate date, @enddate date )
returns table 
as

		 return
		(select * from  vw_Shifts_by sb where @employeeid= sb.EmployeeID and  sb.ShiftDate between @startdate and @enddate )

GO

/*select * from dbo.shifts_1 (1425210,'032002843', '2019-01-01','2019-12-12') order by ShiftDate, ShiftStartTime */


-----------------------------===============function for question 4=========================-------------------------------
CREATE function dbo.preferedShifts(@startdate date,@enddate date,@companyID int)
returns table
as
return(
select * from vw_Shifts_by SB
where shiftdate between @startdate and @enddate and companyID = @companyID)
go
/*select * from dbo.preferedShifts('07-14-2019','07-20-2019',1376225)*/

---------======================================================================================-----------------------------





